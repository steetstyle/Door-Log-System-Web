<?php
/**
 * Created by PhpStorm.
 * User: darryldecode
 * Date: 3/30/2018
 * Time: 11:37 PM
 */

namespace App\Components\Core\Exceptions;


class InvalidArgumentException extends \Exception
{

}
<?php
/**
 * Created by PhpStorm.
 * User: darryldecode
 * Date: 3/7/2018
 * Time: 9:50 AM
 */

namespace App\Components\Core\Menu;


class MenuItemException extends \Exception
{

}